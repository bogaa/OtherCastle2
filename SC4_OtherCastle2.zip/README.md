# OtherCastle2
A Super Castlevania IV hack

You can test the patches provided in the release folder. You need to patch the Super Castlevania (USA) ROM
for feedback you can also use Discord https://discord.gg/PvFgxRg


Credits:
- IsoFrieze: Tool used to create dissasembly https://github.com/IsoFrieze/DiztinGUIsh
- asar: Code injection patcher https://github.com/RPGHacker/asar 
- RedGuyyyy: Creator of SC4Ed (here is a copy of his work: https://github.com/bogaa/SC4Ed )
- fastROM by VitorVilela7: https://github.com/VitorVilela7/fastrom/tree/master/super-castlevania-iv
- Konami for creating Super Castlevania IV for the SNES (October 31, 1991)


You like to use this to make your own levels? Here is what you need to do:
- Get SC4 US ROM
- Downnload and Save this file where you like to have them. 
- Get SC4Ed (Needed too edit levels)
- Make folder called ROM in root directory and put the ROM in there.
- In the release folder you find (sc4Version2EditInSC4Ed.bps) patch your ROM and put it in the ROM folder. Rename it to sc4.sfc!!

You can click the main.bat file to patch my changes with Asar and a new ROM will be copied into the Root directory. 
Some changes you find in the preMain.asm are applyed to the ROM in the ROM directory. It contains changes that are used by SC4Ed.
It makes it also possible to experiment with the code. Just repatch to apply changes again and get rid of screwups. 
